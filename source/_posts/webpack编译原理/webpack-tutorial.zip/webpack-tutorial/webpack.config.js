const path = require('path')
const VueLoaderPlugin = require('vue-loader/lib/plugin')

module.exports = {
  entry: {
    vue: './src/vue.js',  // vue
    react: './src/react.js' // react
  },
  output: { path: path.resolve(__dirname, 'dist') }, // path必须是绝对路径
  module: {
    rules: [
      {
        test: /\.vue/,
        loader: 'vue-loader'
      },
      {
        test: /\.js/,
        loader: 'babel-loader',
        options: {
          presets: ['@babel/preset-react']
        }
      }
    ]
  },
  plugins: [
    new VueLoaderPlugin() // vue-loader官方要求与Plugin一起使用
  ]
}

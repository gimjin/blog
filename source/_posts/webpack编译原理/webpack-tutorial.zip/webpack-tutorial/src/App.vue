<template>
  <div>
    {{ hello }}
  </div>
</template>

<script>
export default {
  name: 'app',
  data: function () {
    return {
      hello: '你好，Vue。'
    }
  }
}
</script>

// Vue
import Vue from 'vue/dist/vue.esm.js'
import App from './app.vue'

new Vue({
  el: '#vue',
  render: function (createElement) {
    return createElement(App)
  }
})

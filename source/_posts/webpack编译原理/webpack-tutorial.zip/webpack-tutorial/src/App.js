import React, { Component } from 'react'

class App extends Component {
  constructor(props) {
    super(props)
    this.state = { hello: '你好，React。'}
  }

  render() {
    return (
      <div>
        { this.state.hello }
      </div>
    )
  }
}

export default App
